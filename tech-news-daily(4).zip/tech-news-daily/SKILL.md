---
name: tech-news-daily
description: "每日科技新闻自动获取与整理：从 tldr.tech、therundown.ai、morningbrew.com、stratechery.com 采集新闻，生成摘要、标签、市场分析，输出CSV和更新知识图谱。触发词：获取科技新闻、每日新闻整理、AI新闻汇总、tech news、新闻采集。"
---

# tech-news-daily Skill

自动获取并整理每日科技领域新闻，生成结构化 CSV 表格和知识图谱。

## When to Use This Skill

触发此技能的场景：
- 用户输入 `/tech-news-daily` 或 `/科技新闻`
- 用户要求"获取今日科技新闻"、"整理每日新闻"、"采集AI新闻"
- 用户指定日期要求获取该日期的科技新闻汇总

## Not For / Boundaries

此技能不适用：
- 单篇文章的深度分析
- 非科技领域的新闻采集
- 实时突发新闻追踪
- 需要登录或付费墙内容的获取

---

## 快速采集模式（推荐首选）

### 一键采集命令

```bash
python "C:\Users\Zhiyang\.claude\skills\tech-news-daily\scripts\collect_fast.py" \
  --date 2026-06-02 \
  --output "C:\微信公众号" \
  --limit 50
```

### 数据源访问策略

| 网站 | 访问方式 | 成功率 | 说明 |
|------|----------|--------|------|
| TLDR | curl 直接获取 | ✅ 100% | 静态页面，无反爬 |
| Stratechery | curl 直接获取 | ✅ 100% | 静态页面，无反爬 |
| therundown.ai | Jina 备用 / CDP | ⚠️ 80% | Cloudflare 保护 |
| morningbrew.com | CDP | ⚠️ 60% | Cloudflare + 登录态 |

### 执行时间对比

| 模式 | 耗时 | 数据源覆盖 |
|------|------|-----------|
| 快速模式（curl） | 30-60 秒 | TLDR + Stratechery |
| 完整模式（CDP） | 5-10 分钟 | 全部 4 个数据源 |

---

## 完整模式（需要 CDP）

当需要 therundown.ai 或 morningbrew.com 数据时，使用 CDP 模式。

### 前置条件检查

**必须先检查 CDP 可用性：**

```bash
node "C:/Users/Zhiyang/.claude/skills/web-access/scripts/check-deps.mjs"
```

**预期输出：**
```
node: ok (v24.13.0)
chrome: ok (port 9222)
proxy: ready
```

### 如果 Chrome 显示 "not connected"

用户需要在 Chrome 中启用远程调试：

1. 在 Chrome 地址栏输入：`chrome://inspect/#remote-debugging`
2. 勾选 **"Allow remote debugging for this browser instance"**
3. 可能需要重启 Chrome

**提示用户的话术：**
```
检测到 Chrome 未连接远程调试。请完成以下步骤：
1. 在 Chrome 地址栏打开 chrome://inspect/#remote-debugging
2. 勾选 "Allow remote debugging for this browser instance"
3. 完成后告诉我继续
```

### CDP 采集流程

```bash
# 1. 创建新标签页
curl -s "http://localhost:3456/new?url=https://tldr.tech/"

# 2. 提取文章链接（返回 targetId）
curl -s -X POST "http://localhost:3456/eval?target=TARGET_ID" -d 'JS代码'

# 3. 关闭标签页
curl -s "http://localhost:3456/close?target=TARGET_ID"
```

**注意：所有 CDP 操作通过 web-access skill 执行，不要直接调用 agent-browser。**

---

## 执行流程总览

```text
步骤 1：快速采集（首选）
        ↓
   curl 直接获取 TLDR + Stratechery
        ↓
   成功 → 步骤 3
   失败 → 步骤 2

步骤 2：CDP 采集（备用）
        ↓
   检查 CDP 可用性
        ↓
   可用 → 采集 therundown.ai / morningbrew.com
   不可用 → 提示用户启用远程调试

步骤 3：生成结构化内容
        ↓
   AI 生成：核心摘要、技术标签、术语识别、市场分析

步骤 4：存储输出
        ↓
   调用 process_news.py
   输出：CSV + 知识图谱 + 历史记录
```

---

## 常见问题与解决方案

### Q1: "Chrome not connected" 错误

**原因**：Chrome 未启用远程调试

**解决**：
```
1. 打开 chrome://inspect/#remote-debugging
2. 勾选 "Allow remote debugging"
3. 重启 Chrome 后重试
```

### Q2: 编码错误 UnicodeDecodeError

**原因**：Windows subprocess 默认 GBK 编码

**解决**：已在 collect_fast.py 中修复，使用 `decode('utf-8', errors='ignore')`

### Q3: therundown.ai 采集失败

**原因**：Cloudflare 保护

**解决方案优先级：**
1. 使用 Jina 备用：`curl "https://r.jina.ai/https://www.therundown.ai/"`
2. 使用 CDP（需要先启用远程调试）
3. 跳过该数据源，仅采集 TLDR + Stratechery

### Q4: morningbrew.com 显示验证页面

**原因**：Cloudflare 验证

**解决**：使用 CDP 等待验证完成（约 10-15 秒）

---

## 输出文件结构

```text
C:\微信公众号\
├── collected_raw_YYYY-MM-DD.json      # 原始采集数据
├── structured_news_YYYY-MM-DD.json    # AI 处理后的完整数据
├── output/
│   └── tech_news_YYYY-MM-DD.csv       # 最终 CSV 输出（13列）
├── knowledge_graph.json               # 知识图谱
└── history.json                       # 历史记录（去重用）
```

---

## CSV 输出字段（13列）

| 字段 | 说明 | 示例 |
|------|------|------|
| 日期 | 采集日期 | 2026-06-02 |
| 标题 | 文章标题 | Claude Opus 4.8 发布 |
| 链接 | 原文URL | https://... |
| 来源 | 数据源 | tldr.tech |
| 分类 | 内容分类 | AI |
| 作者 | 文章作者 | Ben Thompson |
| 媒体类型 | 权威媒体/行业博客 | 行业博客 |
| 核心摘要 | 200-300字摘要 | ... |
| 技术标签 | 1-3个标签 | 人工智能、大语言模型 |
| 技术术语 | 识别的术语 | 大语言模型(LLM) |
| 术语解释 | 术语说明 | ... |
| 发展阶段 | 萌芽期/成长期/成熟期 | 成熟期 |
| 市场分析 | 相关公司+市场影响 | ... |

---

## 分类优先级排序

```
AI(1) > TECH(2) > Tech(3) > AUTO(4) > US ECONOMY(5) > BUSINESS(6) >
Tech Analysis(7) > Dev(8) > IT(9) > Product(10) > Marketing(11)
```

---

## 存储脚本用法

```bash
# 存储结构化数据
python "C:\Users\Zhiyang\.claude\skills\tech-news-daily\process_news.py" \
  --date 2026-06-02 \
  --input "C:\微信公众号\structured_news_2026-06-02.json" \
  --base-dir "C:\微信公众号"

# 查看状态
python "C:\Users\Zhiyang\.claude\skills\tech-news-daily\process_news.py" \
  --status \
  --base-dir "C:\微信公众号"
```

---

## 技术发展阶段定义

| 阶段 | 定义 | 示例 |
|------|------|------|
| 萌芽期 | 技术概念刚出现，无商业化 | AGI、量子计算应用 |
| 成长期 | 技术快速发展，开始应用 | 多模态AI、推理模型、机器人 |
| 成熟期 | 技术稳定，广泛应用 | LLM、API、云计算、电动汽车 |
| 衰退期 | 技术被替代或边缘化 | 传统SEO、单体架构 |

---

## File Structure

```text
C:\Users\Zhiyang\.claude\skills\tech-news-daily\
├── SKILL.md                          # 本文档
├── process_news.py                   # 存储脚本
├── scripts\
│   └── collect_fast.py               # 快速采集脚本（推荐）
└── references\
    ├── data-sources.md               # 数据源详细说明
    ├── output-format.md              # 输出格式定义
    ├── knowledge-graph-spec.md       # 知识图谱结构
    └── market-analysis.md            # 市场分析规则
```

---

## 维护记录

| 日期 | 变更 |
|------|------|
| 2026-06-02 | 新增快速采集脚本，优化执行流程，修复编码问题 |
| 2026-06-01 | 初始版本 |