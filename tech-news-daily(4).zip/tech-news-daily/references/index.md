# tech-news-daily References Index

本目录包含 tech-news-daily skill 的详细参考文档。

## 文档导航

| 文档 | 说明 | 用途 |
|------|------|------|
| [data-sources.md](data-sources.md) | 数据源详细说明 | 了解各网站的访问策略和分类结构 |
| [output-format.md](output-format.md) | 输出格式定义 | CSV字段详解和示例 |
| [knowledge-graph-spec.md](knowledge-graph-spec.md) | 知识图谱规范 | 节点类型和更新规则 |
| [market-analysis.md](market-analysis.md) | 市场分析规则 | 股价关联和分析师观点来源 |

## 快速查找

### 按主题查找

- **数据采集**: → data-sources.md
- **输出格式**: → output-format.md  
- **知识图谱**: → knowledge-graph-spec.md
- **市场分析**: → market-analysis.md

### 按问题查找

- "如何访问 morningbrew.com?" → data-sources.md#morningbrew
- "CSV有哪些字段?" → output-format.md#csv-fields
- "知识图谱节点如何定义?" → knowledge-graph-spec.md#node-types
- "市场分析数据从哪来?" → market-analysis.md#data-sources

## 维护记录

- 2026-06-01: 初始创建，包含4个核心参考文档