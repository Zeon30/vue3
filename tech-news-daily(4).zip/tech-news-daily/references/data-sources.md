# Data Sources Reference

本文档详细说明 tech-news-daily skill 使用的数据源及其访问策略。

## 数据源概览

| 网站 | 类型 | 更新频率 | 访问方式 |
|------|------|----------|----------|
| tldr.tech | 日更聚合 | 每日 | CDP浏览器 |
| therundown.ai | 日更通讯 | 每日 | CDP浏览器 |
| morningbrew.com | 日更新闻 | 每日 | CDP浏览器 |
| stratechery.com | 周更分析 | 每周 | CDP浏览器 |

---

## tldr.tech

### 基本信息
- **URL**: https://tldr.tech/
- **类型**: 科技新闻聚合通讯
- **分类**: Tech, AI, Dev, Product, IT, Marketing

### 访问策略

```text
URL格式: https://tldr.tech/{category}/{YYYY-MM-DD}
示例: https://tldr.tech/ai/2026-06-01
```

### 分类说明

| 分类 | URL路径 | 内容类型 |
|------|---------|----------|
| Tech | /tech | 通用科技新闻 |
| AI | /ai | 人工智能、机器学习 |
| Dev | /dev | 软件开发、编程语言 |
| Product | /product | 产品设计、用户体验 |
| IT | /it | 企业IT、云计算 |
| Marketing | /marketing | 数字营销、增长策略 |

### 数据提取要点

- 每个分类每天约10-20条新闻
- 新闻链接包含 `utm_source=tldr{category}` 参数
- 需要点击进入详情页获取完整内容
- 作者通常标记为 "TLDR Team"

---

## therundown.ai

### 基本信息
- **URL**: https://www.therundown.ai/
- **类型**: AI行业新闻通讯
- **内容**: Latest Articles 部分

### 访问策略

```text
首页直接访问，提取 Latest Articles 区块
文章URL格式: https://www.therundown.ai/p/{slug}
```

### 数据提取要点

- 只需获取 Latest Articles 前5篇
- 文章包含完整内容，需要点击进入详情
- 作者格式: "Zach Mink, Joey Liu, Rowan Cheung, Shubham Sharma & Jennifer Mossalgue"
- 发布日期格式: "Jun 1, 2026"

---

## morningbrew.com

### 基本信息
- **URL**: https://www.morningbrew.com/search
- **类型**: 商业新闻通讯
- **分类**: TECH, AUTO, US ECONOMY, BUSINESS

### 访问策略

```text
搜索页面: https://www.morningbrew.com/search
文章URL格式: https://www.morningbrew.com/stories/{slug}
```

### 分类说明

| 分类 | 内容类型 | 典型文章 |
|------|----------|----------|
| TECH | 科技、AI | 公司动态、产品发布 |
| AUTO | 汽车、电动车 | 新车发布、行业分析 |
| US ECONOMY | 美国经济 | 宏观指标、劳动力市场 |
| BUSINESS | 商业动态 | 公司战略、市场变化 |

### 数据提取要点

- 使用搜索功能按分类筛选
- 每个分类约5条/天
- 文章详情页包含完整内容和作者信息
- 作者格式: "Brendan Cosgrove", "Matty Merritt", "Dave Lozo"

---

## stratechery.com

### 基本信息
- **URL**: https://stratechery.com/
- **类型**: 科技战略分析博客
- **作者**: Ben Thompson

### 访问策略

```text
首页直接访问，提取文章列表
文章URL格式: https://stratechery.com/YYYY/{slug}/
```

### 数据提取要点

- 首页显示约15-20篇文章
- **无需点击进入详情页**，首页已包含足够信息
- 所有文章作者为 Ben Thompson
- 发布日期格式: "Monday, June 1, 2026"
- 内容类型: 深度分析文章、访谈、周报

### 文章类型

| 类型 | 特征 | 频率 |
|------|------|------|
| 深度分析 | 长文，战略分析 | 每周2-3篇 |
| 访谈 | "An Interview with..." | 每周1篇 |
| 周报 | "This Week in Stratechery" | 每周1篇 |

---

## 页面加载策略

### 等待时间

```text
推荐等待: 6秒
原因: 平衡加载完整性和效率
注意: 不等待页面完全加载（可能触发反爬）
```

### agent-browser CDP 操作流程

运行任何采集命令前，先启动浏览器：

```powershell
powershell -ExecutionPolicy Bypass -File "C:\Users\86136\.agent-browser\start-browser.ps1"
```

所有 `agent-browser` 命令都必须追加 `--cdp 9333`，例如：

```bash
agent-browser open "https://tldr.tech/" --cdp 9333
agent-browser snapshot --cdp 9333
```

推荐流程：

```text
1. 调用 agent-browser skill，读取当前版本的 core 用法
2. 启动浏览器：start-browser.ps1
3. 打开目标页面：agent-browser open <url> --cdp 9333
4. 等待页面加载，必要时滚动触发懒加载
5. 使用 snapshot / extract 等命令采集标题、链接、日期、作者、正文摘要
6. 将所有来源合并保存为 collected_news_YYYY-MM-DD.json
7. 采集完成或失败后执行 stop-browser.ps1
```

关闭浏览器：

```powershell
powershell -ExecutionPolicy Bypass -File "C:\Users\86136\.agent-browser\stop-browser.ps1"
```

---

## 常见问题

### Q: 页面加载超时怎么办？
A: 增加等待时间到10秒，或使用 `/scroll` 触发懒加载

### Q: 遇到反爬限制怎么办？
A: web-access skill 已内置防护措施，包括随机延迟和浏览器指纹模拟

### Q: 如何判断数据是否完整？
A: 检查文章数量是否在预期范围内，验证日期范围是否正确

---

## 维护记录

- 2026-06-01: 初始创建，包含4个数据源详细说明