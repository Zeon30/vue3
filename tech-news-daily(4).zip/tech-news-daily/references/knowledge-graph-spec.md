# Knowledge Graph Specification

本文档定义 tech-news-daily skill 的知识图谱结构和更新规则。

## 知识图谱概述

知识图谱用于记录新闻中出现的技术、公司、人物等实体及其关系，支持后续的关联分析和知识检索。

### 文件位置

```text
C:\微信公众号\knowledge_graph.json
```

---

## 结构定义

### 顶层结构

```json
{
  "nodes": [...],    // 实体节点数组
  "edges": [...],    // 关系边数组（预留）
  "metadata": {...}  // 元数据
}
```

### Node 结构

```json
{
  "id": "实体唯一标识",
  "label": "节点类型",
  "source": "来源网站",
  "date": "添加日期"
}
```

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| id | string | ✓ | 实体唯一标识，同类型不可重复 |
| label | enum | ✓ | 技术/公司/人物 |
| source | string | ✓ | 来源网站域名 |
| date | string | ✓ | 添加日期，格式 YYYY-MM-DD |

### Edge 结构（预留）

```json
{
  "from": "源节点id",
  "to": "目标节点id",
  "relation": "关系类型",
  "source": "来源文章",
  "date": "建立日期"
}
```

### Metadata 结构

```json
{
  "created": "图谱创建日期",
  "lastUpdated": "最后更新日期",
  "version": "版本号"
}
```

---

## 节点类型定义

### 技术节点

```text
label: "技术"
id格式: 中文术语名称
来源: 从技术标签字段提取

示例节点:
- 人工智能
- 机器学习
- 大语言模型
- 深度学习
- 自然语言处理
- 计算机视觉
- 云计算
- 数字营销
- 产品设计
```

### 公司节点

```text
label: "公司"
id格式: 英文公司名（官方名称）
来源: 从新闻标题、内容、市场分析中提取

示例节点:
- Anthropic
- OpenAI
- Google
- Microsoft
- Apple
- SpaceX
- Tesla
- Dell
- Amazon
- Nvidia
- Meta
- Ferrari
- Ford
- Waymo
```

### 人物节点

```text
label: "人物"
id格式: 英文人名（First Last）
来源: 从作者字段、访谈标题中提取

示例节点:
- Ben Thompson
- Demis Hassabis
- Sam Altman
- Elon Musk
- Jensen Huang
```

---

## 更新规则

### 核心原则：叠加更新

```text
规则1: 只添加新节点，永不删除已有节点
规则2: 通过 id 字段判断唯一性（同label下）
规则3: 每次更新记录 source 和 date
规则4: metadata.lastUpdated 更新为当天日期
```

### 添加新节点流程

```python
1. 提取候选实体（技术标签、公司名、人名）
2. 读取现有 knowledge_graph.json
3. 获取已有节点 id 集合: existing_ids = {n["id"] for n in nodes}
4. 对每个候选实体:
   if entity not in existing_ids:
     nodes.append({
       "id": entity,
       "label": label_type,
       "source": article_source,
       "date": current_date
     })
5. 更新 metadata.lastUpdated
6. 写入文件
```

### 示例：添加新节点

**初始状态**:
```json
{
  "nodes": [{"id": "人工智能", "label": "技术", "source": "tldr.tech", "date": "2026-06-01"}]
}
```

**新增节点**:
```json
{
  "nodes": [
    {"id": "人工智能", "label": "技术", "source": "tldr.tech", "date": "2026-06-01"},
    {"id": "Anthropic", "label": "公司", "source": "tldr.tech", "date": "2026-06-02"},
    {"id": "机器学习", "label": "技术", "source": "therundown.ai", "date": "2026-06-02"}
  ]
}
```

---

## 实体提取规则

### 技术实体提取

```text
来源: CSV的技术标签字段
提取: 直接使用标签作为节点id
数量: 每篇文章1-3个技术标签
```

### 公司实体提取

```text
来源: 新闻标题、内容、市场分析
匹配规则:
  - 公司名称出现于标题
  - 股票代码对应公司
  - 市场分析中提及的公司

常见公司映射:
  - GOOG/GOOGLE → Google
  - MSFT → Microsoft
  - AAPL → Apple
  - NVDA → Nvidia
  - TSLA → Tesla
  - META → Meta
  - DELL → Dell
  - AMZN → Amazon
```

### 人物实体提取

```text
来源: 作者字段、访谈类文章标题
匹配规则:
  - 作者字段: "Ben Thompson" → 人物节点
  - 访谈标题: "An Interview with Eric Seufert" → "Eric Seufert"
  - 引用观点: "Demis Hassabis on AGI" → "Demis Hassabis"
```

---

## 统计查询

### 查询节点数量

```python
import json
with open("knowledge_graph.json") as f:
    kg = json.load(f)
    
total = len(kg["nodes"])
by_type = {}
for n in kg["nodes"]:
    by_type[n["label"]] = by_type.get(n["label"], 0) + 1

print(f"总节点数: {total}")
print(f"技术节点: {by_type.get('技术', 0)}")
print(f"公司节点: {by_type.get('公司', 0)}")
print(f"人物节点: {by_type.get('人物', 0)}")
```

### 查询最近添加

```python
recent = sorted(kg["nodes"], key=lambda x: x["date"], reverse=True)[:10]
for n in recent:
    print(f"{n['date']} - {n['label']}: {n['id']} (来源: {n['source']})")
```

---

## 关系边（预留设计）

### 未来支持的边类型

| relation | from → to | 说明 |
|----------|-----------|------|
| develops | 公司 → 技术 | 公司开发该技术 |
| uses | 公司 → 技术 | 公司使用该技术 |
| founded_by | 公司 → 人物 | 公司由该人物创立 |
| works_at | 人物 → 公司 | 人物就职于该公司 |
| mentions | 技术 → 技术 | 技术提及关联技术 |

### 边添加时机（未来）

```text
当以下情况出现时，可建立边:
- 文章明确描述公司开发了某技术产品
- 人物与公司的关联关系明确
- 技术之间存在依赖或关联关系
```

---

## 维护记录

- 2026-06-01: 初始创建，定义节点结构和叠加规则
- 边关系功能预留，待后续需求明确后实现