# Output Format Specification

本文档定义 tech-news-daily skill 的输出格式规范。

## CSV 文件规范

### 基本信息

| 属性 | 值 |
|------|------|
| 文件名 | `tech_news_{YYYY-MM-DD}.csv` |
| 编码 | UTF-8 with BOM (utf-8-sig) |
| 存储位置 | `C:\微信公众号\output\` |
| 记录数 | 30条（按重要性排序） |

### CSV 字段定义

| 序号 | 字段名 | 类型 | 必填 | 说明 |
|------|--------|------|------|------|
| 1 | 日期 | DATE | ✓ | 发布日期，格式 YYYY-MM-DD |
| 2 | 标题 | STRING | ✓ | 新闻标题（原文语言） |
| 3 | 链接 | URL | ✓ | 原文完整链接 |
| 4 | 来源 | STRING | ✓ | 来源网站域名 |
| 5 | 分类 | STRING | ✓ | 内容分类标签 |
| 6 | 作者 | STRING | ✓ | 文章作者姓名 |
| 7 | 媒体类型 | ENUM | ✓ | 官方公告/权威媒体/行业博客/社交媒体 |
| 8 | 核心摘要 | TEXT | ✓ | 200字以上摘要，含举例说明 |
| 9 | 技术标签 | STRING | ✓ | 1-3个细分标签，顿号分隔 |
| 10 | 技术术语 | STRING | | 核心技术术语名称 |
| 11 | 术语解释 | TEXT | | 通俗易懂的术语解释 |
| 12 | 发展阶段 | ENUM | | 萌芽期/成长期/成熟期/衰退期 |
| 13 | 市场分析 | TEXT | | 关联股价、指数、分析师观点 |

---

## 字段详细说明

### 1. 日期

```text
格式: YYYY-MM-DD
示例: 2026-06-01
说明: 文章的原始发布日期，非采集日期
```

### 2. 标题

```text
语言: 原文语言（英文）
示例: Anthropic releases Claude Opus 4.8 with breakthrough reasoning
限制: 保持原文完整，不翻译
```

### 3. 链接

```text
格式: 完整URL，包含所有参数
示例: https://tldr.tech/ai/2026-06-01
注意: 不要裁剪URL参数
```

### 4. 来源

```text
取值: 域名
可选值: tldr.tech, therundown.ai, morningbrew.com, stratechery.com
```

### 5. 分类

```text
取值: 根据来源和内容确定
映射:
  tldr.tech → Tech, AI, Dev, Product, IT, Marketing
  therundown.ai → AI
  morningbrew.com → TECH, AUTO, US ECONOMY, BUSINESS
  stratechery.com → Tech Analysis
```

### 6. 作者

```text
格式: 英文原名
示例: Ben Thompson, Matty Merritt, TLDR Team
多个作者: 用逗号分隔
```

### 7. 媒体类型

| 类型 | 定义 | 示例来源 |
|------|------|----------|
| 官方公告 | 公司/组织官方发布 | 公司博客、产品页面 |
| 权威媒体 | 专业新闻机构 | tldr.tech, morningbrew.com |
| 行业博客 | 行业专家/分析师 | therundown.ai, stratechery.com |
| 社交媒体 | 社区平台内容 | Twitter/X, Reddit |

### 8. 核心摘要

```text
要求:
- 200字以上
- 包含核心事实
- 包含具体举例
- 包含市场影响分析

示例格式:
{公司/组织}发布了{产品/服务}，主要特点是{核心功能}。
例如，{具体例子}。
市场影响方面，{影响描述}。
分析师认为，{分析师观点}。
```

### 9. 技术标签

```text
数量: 1-3个
分隔符: 中文顿号（、）
示例: 人工智能、机器学习、大语言模型

标签分类:
- AI类: 人工智能、机器学习、深度学习、大语言模型、计算机视觉
- 开发类: 软件开发、编程语言、开发工具、云原生
- 产品类: 产品设计、用户体验、产品创新
- 基础设施类: 云计算、基础设施、企业IT
- 商业类: 商业模式、战略分析、科技投资
- 经济类: 宏观经济、劳动力市场、商业周期
```

### 10-12. 技术术语相关

```text
术语名称: 中文全称(英文缩写)
示例: 大语言模型(Large Language Model)

术语解释: 通俗易懂的描述
示例: 一种能够理解和生成人类语言的人工智能模型，通过海量文本数据训练而成

发展阶段:
- 萌芽期: 技术概念刚出现，无商业化
- 成长期: 技术快速发展，开始应用
- 成熟期: 技术稳定，广泛应用
- 衰退期: 技术被替代或边缘化
```

### 13. 市场分析

```text
格式:
相关公司股价：{公司}（{股票代码}，{涨跌幅}）
分析师观点：{机构}{评级}，{观点摘要}
行业指数：{指数名称}{涨跌幅}

示例:
相关公司股价：Anthropic（未上市，估值约$800亿）、Google（GOOG，+2.3%）
分析师观点：摩根士丹利维持Google"增持"评级，认为AI竞争加剧将推动行业整体创新
行业指数：纳斯达克科技指数（NDXT）当日上涨1.2%
```

---

## 输出示例

### CSV 行示例

```csv
2026-06-01,Anthropic releases Claude Opus 4.8 with breakthrough reasoning,https://tldr.tech/tech/2026-06-01,tldr.tech,Tech,TLDR Team,权威媒体,"Anthropic发布了Claude Opus 4.8模型，在推理能力方面取得重大突破。该模型在复杂的逻辑推理、数学问题和代码生成任务上表现出色，超越了此前的版本。例如，在GSM8K数学基准测试中，Opus 4.8达到了95%以上的准确率，接近人类专家水平。市场影响方面，Anthropic的估值进一步攀升，企业客户对Claude的需求持续增长，特别是在金融服务和医疗健康领域。",科技产业、企业服务、数字化转型,大语言模型(Large Language Model),一种能够理解和生成人类语言的人工智能模型，通过海量文本数据训练而成,成熟期,"相关公司股价：Anthropic（未上市，估值约$800亿）、Google（GOOG，+2.3%）。分析师观点：摩根士丹利维持Google""增持""评级，认为AI竞争加剧将推动行业整体创新。行业指数：纳斯达克科技指数（NDXT）当日上涨1.2%。"
```

---

## 知识图谱输出

### 文件位置

```text
C:\微信公众号\knowledge_graph.json
```

### JSON 结构

```json
{
  "nodes": [
    {
      "id": "人工智能",
      "label": "技术",
      "source": "tldr.tech",
      "date": "2026-06-01"
    },
    {
      "id": "Anthropic",
      "label": "公司",
      "source": "tldr.tech",
      "date": "2026-06-01"
    },
    {
      "id": "Ben Thompson",
      "label": "人物",
      "source": "stratechery.com",
      "date": "2026-06-01"
    }
  ],
  "edges": [],
  "metadata": {
    "created": "2026-06-01",
    "lastUpdated": "2026-06-01",
    "version": "1.0"
  }
}
```

### 节点类型定义

| label | id格式 | 示例 |
|-------|--------|------|
| 技术 | 中文术语 | 人工智能、机器学习 |
| 公司 | 英文公司名 | Anthropic, OpenAI |
| 人物 | 英文人名 | Ben Thompson |

---

## 历史记录输出

### 文件位置

```text
C:\微信公众号\history.json
```

### JSON 结构

```json
{
  "readArticles": [
    {
      "title": "文章标题",
      "link": "https://...",
      "source": "tldr.tech",
      "date": "2026-06-01",
      "readDate": "2026-06-01"
    }
  ],
  "lastUpdate": "2026-06-01",
  "sources": {
    "tldr.tech": [],
    "therundown.ai": [],
    "morningbrew.com": [],
    "stratechery.com": []
  }
}
```

---

## 维护记录

- 2026-06-01: 初始创建，定义CSV、知识图谱、历史记录格式