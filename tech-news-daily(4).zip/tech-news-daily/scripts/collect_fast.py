#!/usr/bin/env python3
"""
tech-news-daily 快速采集脚本
使用 curl/requests 直接获取静态页面，绕过 CDP 提升速度

用法:
    python collect_fast.py --date 2026-06-02 --output "C:\\微信公众号"
"""

import argparse
import json
import re
import subprocess
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse

# 分类映射
CATEGORY_MAP = {
    "newsletter": "Tech",
    "ai": "AI",
    "dev": "Dev",
    "product": "Product",
    "it": "IT",
    "infosec": "IT",
    "design": "Tech",
    "marketing": "Marketing",
}

# 分类优先级（用于排序）
CATEGORY_PRIORITY = {
    "AI": 1,
    "TECH": 2,
    "Tech": 3,
    "AUTO": 4,
    "US ECONOMY": 5,
    "BUSINESS": 6,
    "Tech Analysis": 7,
    "Dev": 8,
    "IT": 9,
    "Product": 10,
    "Marketing": 11,
}


def curl_fetch(url: str, timeout: int = 15) -> str:
    """使用 curl 获取页面内容"""
    try:
        result = subprocess.run(
            [
                "curl", "-s", "-L", url,
                "-H", "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                "--connect-timeout", str(timeout),
                "--max-time", str(timeout * 3)
            ],
            capture_output=True,
            timeout=timeout * 4
        )
        # 尝试 UTF-8 解码，失败则使用 latin-1
        try:
            return result.stdout.decode('utf-8')
        except UnicodeDecodeError:
            return result.stdout.decode('latin-1', errors='ignore')
    except Exception as e:
        print(f"  curl 失败: {e}")
        return ""


def extract_tldr_articles(html: str, date: str) -> list:
    """从 TLDR 页面提取文章"""
    articles = []
    seen = set()

    # 匹配带 utm_source=tldr* 的链接
    pattern = r'href="(https://[^"]*utm_source=tldr[a-z]*)"'
    matches = re.findall(pattern, html)

    for link in matches:
        if link in seen:
            continue
        seen.add(link)

        # 提取分类
        cat_match = re.search(r'utm_source=tldr(\w+)', link)
        category = cat_match.group(1) if cat_match else "newsletter"
        category = CATEGORY_MAP.get(category, category.capitalize())

        # 从链接提取标题（简化版，后续可用 Jina 补充）
        title = "待提取标题"

        articles.append({
            "title": title,
            "link": link,
            "source": "tldr.tech",
            "category": category,
            "date": date
        })

    return articles


def extract_stratechery_articles(html: str, date: str) -> list:
    """从 Stratechery 页面提取文章"""
    articles = []
    seen = set()

    # 匹配当前年份的文章链接
    pattern = r'href="(https://stratechery\.com/2026/[^"/]+/)"'
    matches = re.findall(pattern, html)

    for link in matches:
        if link in seen:
            continue
        seen.add(link)

        # 从 URL 提取标题
        slug = link.rstrip('/').split('/')[-1]
        title = slug.replace('-', ' ').title()

        articles.append({
            "title": title,
            "link": link,
            "source": "stratechery.com",
            "category": "Tech Analysis",
            "date": date,
            "author": "Ben Thompson"
        })

    return articles[:15]  # 限制数量


def extract_therundown_articles(html: str, date: str) -> list:
    """从 therundown.ai 页面提取文章（Jina 格式）"""
    articles = []
    seen = set()

    # 匹配文章链接
    pattern = r'(https://www\.therundown\.com/p/[a-z0-9-]+)'
    matches = re.findall(pattern, html)

    for link in matches:
        if link in seen:
            continue
        seen.add(link)

        # 从 URL 提取标题
        slug = link.split('/')[-1]
        title = slug.replace('-', ' ').title()

        articles.append({
            "title": title,
            "link": link,
            "source": "therundown.ai",
            "category": "AI",
            "date": date,
            "author": "Zach Mink, +4"
        })

    return articles[:10]


def extract_morningbrew_articles(html: str, date: str) -> list:
    """从 morningbrew.com 页面提取文章"""
    articles = []
    seen = set()

    # 匹配文章链接
    pattern = r'href="(https://www\.morningbrew\.com/stories/[^"]+)"'
    matches = re.findall(pattern, html)

    for link in matches:
        if link in seen:
            continue
        seen.add(link)

        articles.append({
            "title": "待提取标题",
            "link": link,
            "source": "morningbrew.com",
            "category": "TECH",
            "date": date
        })

    return articles[:15]


def fetch_with_jina(url: str) -> str:
    """使用 Jina.ai 服务获取页面内容"""
    jina_url = f"https://r.jina.ai/{url}"
    return curl_fetch(jina_url, timeout=20)


def main():
    parser = argparse.ArgumentParser(description="科技新闻快速采集")
    parser.add_argument("--date", default=datetime.now().strftime("%Y-%m-%d"), help="采集日期")
    parser.add_argument("--output", default="C:\\微信公众号", help="输出目录")
    parser.add_argument("--limit", type=int, default=50, help="最大文章数")
    args = parser.parse_args()

    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)
    output_file = output_dir / f"collected_raw_{args.date}.json"

    print(f"=== 科技新闻快速采集 ===")
    print(f"日期: {args.date}")
    print(f"输出: {output_file}")
    print()

    all_articles = []

    # 1. 采集 TLDR
    print("[1/4] 采集 TLDR...")
    html = curl_fetch("https://tldr.tech/")
    articles = extract_tldr_articles(html, args.date)
    print(f"   TLDR 文章数: {len(articles)}")
    all_articles.extend(articles)

    # 2. 采集 Stratechery
    print("[2/4] 采集 Stratechery...")
    html = curl_fetch("https://stratechery.com/")
    articles = extract_stratechery_articles(html, args.date)
    print(f"   Stratechery 文章数: {len(articles)}")
    all_articles.extend(articles)

    # 3. 采集 therundown.ai (尝试 Jina 备用)
    print("[3/4] 采集 therundown.ai...")
    html = fetch_with_jina("https://www.therundown.ai/")
    if html:
        articles = extract_therundown_articles(html, args.date)
        print(f"   therundown.ai 文章数: {len(articles)}")
        all_articles.extend(articles)
    else:
        print("   therundown.ai 需要 CDP (Cloudflare 保护)")

    # 4. 采集 morningbrew.com
    print("[4/4] 采集 morningbrew.com...")
    html = curl_fetch("https://www.morningbrew.com/search?q=TECH")
    if html and "morningbrew.com/stories" in html:
        articles = extract_morningbrew_articles(html, args.date)
        print(f"   morningbrew.com 文章数: {len(articles)}")
        all_articles.extend(articles)
    else:
        print("   morningbrew.com 需要 CDP (Cloudflare 保护)")

    # 按分类优先级排序
    all_articles.sort(
        key=lambda x: CATEGORY_PRIORITY.get(x.get("category", "Tech"), 99)
    )

    # 限制数量
    all_articles = all_articles[:args.limit]

    # 保存 JSON
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(all_articles, f, ensure_ascii=False, indent=2)

    print()
    print(f"=== 采集完成 ===")
    print(f"输出文件: {output_file}")
    print(f"总文章数: {len(all_articles)}")

    # 统计各分类数量
    categories = {}
    for article in all_articles:
        cat = article.get("category", "Unknown")
        categories[cat] = categories.get(cat, 0) + 1

    print("\n分类统计:")
    for cat, count in sorted(categories.items(), key=lambda x: CATEGORY_PRIORITY.get(x[0], 99)):
        print(f"  {cat}: {count}")


if __name__ == "__main__":
    main()
