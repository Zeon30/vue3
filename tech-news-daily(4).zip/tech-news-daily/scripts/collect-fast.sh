#!/bin/bash
# tech-news-daily 快速采集脚本
# 使用 curl 直接获取静态页面，绕过 CDP 提升速度
# 用法: ./collect-fast.sh [output_dir]

set -e

OUTPUT_DIR="${1:-C:/微信公众号}"
DATE=$(date +%Y-%m-%d)
OUTPUT_FILE="${OUTPUT_DIR}/collected_raw_${DATE}.json"

echo "=== 科技新闻快速采集 ==="
echo "日期: $DATE"
echo "输出: $OUTPUT_FILE"
echo ""

# 临时文件
TMP_TLDR=$(mktemp)
TMP_STRATECHERY=$(mktemp)
TMP_THERUNDOWN=$(mktemp)
TMP_MORNINGBREW=$(mktemp)

# 1. 采集 TLDR (curl 直接获取)
echo "[1/4] 采集 TLDR..."
curl -s -L "https://tldr.tech/" -H "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36" \
  -o "$TMP_TLDR"

# 解析 TLDR 文章链接
TLDR_ARTICLES=$(grep -oE 'href="https://[^"]*utm_source=tldr[a-z]*"' "$TMP_TLDR" | \
  sed 's/href="//g' | sed 's/"//g' | sort -u | head -60)

echo "   TLDR 文章数: $(echo "$TLDR_ARTICLES" | wc -l)"

# 2. 采集 Stratechery (curl 直接获取)
echo "[2/4] 采集 Stratechery..."
curl -s -L "https://stratechery.com/" -H "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36" \
  -o "$TMP_STRATECHERY"

# 解析 Stratechery 文章链接
STRATECHERY_ARTICLES=$(grep -oE 'href="https://stratechery\.com/2026/[^"]*"' "$TMP_STRATECHERY" | \
  sed 's/href="//g' | sed 's/"//g' | sort -u | head -20)

echo "   Stratechery 文章数: $(echo "$STRATECHERY_ARTICLES" | wc -l)"

# 3. 采集 therundown.ai (需要 CDP，这里用备用方案)
echo "[3/4] 采集 therundown.ai..."
# therundown.ai 有 Cloudflare 保护，尝试用 Jina 作为备用
curl -s -L "https://r.jina.ai/https://www.therundown.ai/" \
  -H "User-Agent: Mozilla/5.0" \
  -o "$TMP_THERUNDOWN" 2>/dev/null || echo "   Jina 备用失败，需要 CDP"

# 从 Jina 结果提取文章链接
THERUNDOWN_ARTICLES=$(grep -oE 'https://www\.therundown\.ai/p/[a-z0-9-]+' "$TMP_THERUNDOWN" | sort -u | head -10)
echo "   therundown.ai 文章数: $(echo "$THERUNDOWN_ARTICLES" | wc -l)"

# 4. 采集 morningbrew.com TECH 分类
echo "[4/4] 采集 morningbrew.com..."
# 尝试直接获取搜索页面
curl -s -L "https://www.morningbrew.com/search?q=TECH" \
  -H "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36" \
  -o "$TMP_MORNINGBREW" 2>/dev/null || echo "   morningbrew 需要登录态"

# 从结果提取文章链接
MORNINGBREW_ARTICLES=$(grep -oE 'href="https://www\.morningbrew\.com/stories/[^"]*"' "$TMP_MORNINGBREW" | \
  sed 's/href="//g' | sed 's/"//g' | sort -u | head -15)
echo "   morningbrew.com 文章数: $(echo "$MORNINGBREW_ARTICLES" | wc -l)"

# 5. 合并生成 JSON
echo ""
echo "=== 生成结构化 JSON ==="

# 开始构建 JSON
echo '[' > "$OUTPUT_FILE"

# 处理 TLDR 文章
FIRST=true
for link in $TLDR_ARTICLES; do
  # 从 URL 提取分类
  category=$(echo "$link" | grep -oE 'utm_source=tldr[a-z]+' | sed 's/utm_source=tldr//')
  if [ -z "$category" ]; then
    category="Tech"
  fi
  # 转换分类名称
  case $category in
    "newsletter") category="Tech" ;;
    "ai") category="AI" ;;
    "dev") category="Dev" ;;
    "product") category="Product" ;;
    "it") category="IT" ;;
    "infosec") category="IT" ;;
    "design") category="Tech" ;;
    *) category=$(echo "$category" | sed 's/.*/\u&/') ;;
  esac

  # 尝试从页面提取标题（使用 Jina）
  title=""
  if [ "$FIRST" = false ]; then
    echo ',' >> "$OUTPUT_FILE"
  fi

  # 生成基础 JSON 条目
  cat >> "$OUTPUT_FILE" << ARTICLE_JSON
  {
    "title": "待提取标题",
    "link": "$link",
    "source": "tldr.tech",
    "category": "$category",
    "date": "$DATE"
  }
ARTICLE_JSON
  FIRST=false
done

# 处理 Stratechery 文章
for link in $STRATECHERY_ARTICLES; do
  # 从 URL 提取标题
  slug=$(echo "$link" | sed 's/https://stratechery.com/2026///' | sed 's//$//')
  title=$(echo "$slug" | sed 's/-/ /g' | sed 's/.*/\u&/')

  echo ',' >> "$OUTPUT_FILE"
  cat >> "$OUTPUT_FILE" << ARTICLE_JSON
  {
    "title": "$title",
    "link": "$link",
    "source": "stratechery.com",
    "category": "Tech Analysis",
    "date": "$DATE",
    "author": "Ben Thompson"
  }
ARTICLE_JSON
done

# 处理 therundown.ai 文章
for link in $THERUNDOWN_ARTICLES; do
  slug=$(echo "$link" | sed 's/https://www.therundown.ai/p//')
  title=$(echo "$slug" | sed 's/-/ /g')

  echo ',' >> "$OUTPUT_FILE"
  cat >> "$OUTPUT_FILE" << ARTICLE_JSON
  {
    "title": "$title",
    "link": "$link",
    "source": "therundown.ai",
    "category": "AI",
    "date": "$DATE",
    "author": "Zach Mink, +4"
  }
ARTICLE_JSON
done

# 处理 morningbrew.com 文章
for link in $MORNINGBREW_ARTICLES; do
  slug=$(echo "$link" | sed 's/https://www.morningbrew.com/stories//')

  echo ',' >> "$OUTPUT_FILE"
  cat >> "$OUTPUT_FILE" << ARTICLE_JSON
  {
    "title": "待提取标题",
    "link": "$link",
    "source": "morningbrew.com",
    "category": "TECH",
    "date": "$DATE"
  }
ARTICLE_JSON
done

echo ']' >> "$OUTPUT_FILE"

# 清理临时文件
rm -f "$TMP_TLDR" "$TMP_STRATECHERY" "$TMP_THERUNDOWN" "$TMP_MORNINGBREW"

echo ""
echo "=== 采集完成 ==="
echo "输出文件: $OUTPUT_FILE"
echo "总文章数: $(grep -c '"link"' "$OUTPUT_FILE")"