#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
科技新闻数据存储脚本

接收已结构化的新闻数据（包含摘要、标签、术语、市场分析等所有字段），
输出 CSV 表格，并更新知识图谱和历史记录。

职责：数据存储和状态文件维护，不负责内容生成。
"""

import argparse
import csv
import json
from datetime import datetime
from pathlib import Path


FIELDNAMES = [
    "日期", "标题", "链接", "来源", "分类", "作者", "媒体类型",
    "核心摘要", "技术标签", "技术术语", "术语解释", "发展阶段", "市场分析"
]

COMPANIES = [
    "Anthropic", "OpenAI", "Google", "Microsoft", "Nvidia", "Dell", "SpaceX",
    "Apple", "Meta", "Amazon", "Tesla", "GitHub", "Figma", "Notion", "AWS",
]

PEOPLE = ["Ben Thompson", "Demis Hassabis", "Sam Altman", "Jensen Huang", "Elon Musk"]


def parse_args():
    parser = argparse.ArgumentParser(description="存储科技新闻结构化数据")
    parser.add_argument("--date", default=datetime.now().strftime("%Y-%m-%d"), help="处理日期，格式 YYYY-MM-DD")
    parser.add_argument("--input", help="已结构化的新闻数据 JSON 路径")
    parser.add_argument("--base-dir", default="C:/微信公众号", help="输出和状态文件目录")
    parser.add_argument("--limit", type=int, default=30, help="最多输出新闻条数")
    parser.add_argument("--status", action="store_true", help="只显示知识图谱和历史记录状态")
    args = parser.parse_args()

    # 状态模式下不需要输入文件
    if not args.status and not args.input:
        parser.error("--input 是必需参数（除非使用 --status）")

    return args


def load_json(path, default):
    path = Path(path)
    if not path.exists():
        return default
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def load_structured_data(input_path):
    """加载已结构化的新闻数据"""
    if not input_path:
        raise ValueError("必须提供 --input 指向已结构化的新闻数据 JSON")

    payload = load_json(input_path, None)
    if isinstance(payload, list):
        return payload
    if isinstance(payload, dict):
        for key in ("articles", "news", "items", "data"):
            value = payload.get(key)
            if isinstance(value, list):
                return value
    raise ValueError("输入 JSON 必须是数组，或包含 articles/news/items/data 数组字段")


def validate_article(article):
    """验证必需字段"""
    required = ["日期", "标题", "链接"]
    for field in required:
        if not article.get(field):
            print(f"警告：缺少必需字段 {field}，跳过该条目")
            return False
    return True


def deduplicate_articles(articles):
    """基于链接去重"""
    seen_links = set()
    unique = []
    for article in articles:
        link = article.get("链接")
        if link in seen_links:
            continue
        unique.append(article)
        seen_links.add(link)
    return unique


def filter_by_limit(articles, limit):
    """限制输出条数"""
    return articles[:limit]


def save_csv(data, base_dir, current_date):
    """保存为 CSV 文件"""
    output_dir = base_dir / "output"
    output_dir.mkdir(parents=True, exist_ok=True)
    csv_path = output_dir / f"tech_news_{current_date}.csv"

    with open(csv_path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDNAMES, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(data)

    return csv_path


def update_knowledge_graph(data, base_dir, current_date):
    """更新知识图谱（叠加模式）"""
    kg_path = base_dir / "knowledge_graph.json"
    kg = load_json(kg_path, {
        "nodes": [],
        "edges": [],
        "metadata": {"created": current_date, "version": "1.0"}
    })

    existing_node_ids = {node.get("id") for node in kg.get("nodes", [])}

    for item in data:
        # 从技术标签提取节点
        tags = item.get("技术标签", "")
        if tags:
            for tag in tags.split("、"):
                add_node(kg, existing_node_ids, tag.strip(), "技术", item.get("来源", "unknown"), current_date)

        # 从标题和摘要提取公司和人物
        text = f"{item.get('标题', '')} {item.get('核心摘要', '')}"
        for company in COMPANIES:
            if company.lower() in text.lower():
                add_node(kg, existing_node_ids, company, "公司", item.get("来源", "unknown"), current_date)

        for person in PEOPLE:
            if person.lower() in text.lower() or person.lower() in item.get("作者", "").lower():
                add_node(kg, existing_node_ids, person, "人物", item.get("来源", "unknown"), current_date)

    kg.setdefault("metadata", {})["lastUpdated"] = current_date

    with open(kg_path, "w", encoding="utf-8") as f:
        json.dump(kg, f, ensure_ascii=False, indent=2)

    return kg_path, len(kg.get("nodes", []))


def add_node(kg, existing_node_ids, node_id, label, source, current_date):
    """添加节点到知识图谱"""
    if not node_id or node_id in existing_node_ids:
        return
    kg.setdefault("nodes", []).append({
        "id": node_id,
        "label": label,
        "source": source,
        "date": current_date,
    })
    existing_node_ids.add(node_id)


def update_history(data, base_dir, current_date):
    """更新历史记录"""
    history_path = base_dir / "history.json"
    history = load_json(history_path, {
        "readArticles": [],
        "lastUpdate": None,
        "sources": {}
    })

    existing_urls = {a.get("link") for a in history.get("readArticles", []) if a.get("link")}
    new_count = 0

    for item in data:
        link = item.get("链接")
        if link in existing_urls:
            continue

        history["readArticles"].append({
            "title": item.get("标题"),
            "link": link,
            "source": item.get("来源"),
            "date": item.get("日期"),
            "readDate": current_date,
        })
        existing_urls.add(link)
        new_count += 1

    history["lastUpdate"] = current_date

    with open(history_path, "w", encoding="utf-8") as f:
        json.dump(history, f, ensure_ascii=False, indent=2)

    return history_path, len(history["readArticles"]), new_count


def show_status(base_dir):
    """显示知识图谱和历史记录状态"""
    kg = load_json(base_dir / "knowledge_graph.json", {"nodes": [], "metadata": {}})
    history = load_json(base_dir / "history.json", {"readArticles": [], "lastUpdate": None})

    # 统计节点类型
    counts = {}
    for node in kg.get("nodes", []):
        label = node.get("label", "未知")
        counts[label] = counts.get(label, 0) + 1

    print("知识图谱状态：")
    print(f"- 总节点数：{len(kg.get('nodes', []))}")
    for label, count in sorted(counts.items()):
        print(f"- {label}节点：{count}")
    print(f"- 最后更新：{kg.get('metadata', {}).get('lastUpdated', '无')}")

    print("\n历史记录状态：")
    print(f"- 已读文章数：{len(history.get('readArticles', []))}")
    print(f"- 最后更新：{history.get('lastUpdate', '无')}")


def main():
    args = parse_args()
    base_dir = Path(args.base_dir)
    base_dir.mkdir(parents=True, exist_ok=True)

    if args.status:
        show_status(base_dir)
        return

    print("=" * 60)
    print("科技新闻数据存储开始")
    print(f"处理日期：{args.date}")
    print(f"输入文件：{args.input}")
    print(f"输出限制：{args.limit} 条")
    print("=" * 60)

    # 加载已结构化的数据
    raw_data = load_structured_data(args.input)

    # 验证必需字段
    valid_data = [article for article in raw_data if validate_article(article)]

    # 去重
    unique_data = deduplicate_articles(valid_data)

    # 限制条数
    limited_data = filter_by_limit(unique_data, args.limit)

    # 保存 CSV
    csv_path = save_csv(limited_data, base_dir, args.date)

    # 更新知识图谱
    kg_path, node_count = update_knowledge_graph(limited_data, base_dir, args.date)

    # 更新历史记录
    history_path, total_count, new_count = update_history(limited_data, base_dir, args.date)

    result = {
        "csv": str(csv_path),
        "knowledge_graph": str(kg_path),
        "history": str(history_path),
        "input_articles": len(raw_data),
        "valid_articles": len(valid_data),
        "unique_articles": len(unique_data),
        "output_articles": len(limited_data),
        "new_articles": new_count,
        "knowledge_graph_nodes": node_count,
        "history_total": total_count,
    }

    print("\n处理完成：")
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()